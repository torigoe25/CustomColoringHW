package edu.up.tryagain;

import androidx.appcompat.app.AppCompatActivity;

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        setContentView(R.layout.activity_main);

        //getting the necessary views
        DrawView drawView = findViewById(R.id.drawview);
        SeekBar redSB = findViewById(R.id.red_seekBar);
        SeekBar blueSB = findViewById(R.id.blue_seekBar);
        SeekBar greenSB = findViewById(R.id.green_seekBar);
        TextView currElemTV = findViewById(R.id.curr_element_tv);
        DrawController drawController = new DrawController(drawView, redSB, greenSB, blueSB, currElemTV);

        //setting drawController as the control listener
        redSB.setOnSeekBarChangeListener(drawController);
        blueSB.setOnSeekBarChangeListener(drawController);
        greenSB.setOnSeekBarChangeListener(drawController);
        drawView.setOnTouchListener(drawController);
    }
}