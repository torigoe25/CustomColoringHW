package edu.up.tryagain;

import static android.graphics.Color.alpha;
import static android.graphics.Color.argb;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.SurfaceView;

/**
    External Citation
    Date: 10 February 2021
    Problem: Needed a good way to identify if a touch event was inside one of the drawn
             components
    Resource: CustomElement.java, CustomCircle.java, CustomRect.java - taken from Nux HW1 helper
              code
    Solution: I implemented these classes and used them as my "components".
 */

/**
    External Citation
    Date: 10 February 2021
    Problem: Needed a way to convert RGB ints to hex color (program didn't like hex colors)
    Resource: https://developer.android.com/reference/android/graphics/Color
    Solution: I implemented the argb method to convert 3 RGB vals and an alpha val to hex
 */

public class DrawView extends SurfaceView {
    //values for drawing components (positions)
    public static final int leavesX = 1150;
    public static final int leavesY = 425;
    public static final int leavesR = 150;
    public static final int grassL = 0;
    public static final int grassT = 775;
    public static final int grassR = 2000;
    public static final int grassB = 900;
    public static final int barkL = 1100;
    public static final int barkT = 575;
    public static final int barkR = 1200;
    public static final int barkB = 775;
    public static final int sunX = 2000;
    public static final int sunY = 0;
    public static final int sunR = 150;

    //values for drawing components (colors)
    public static final int alphaVal = 255;
    public static final int barkInitRVal = 189;
    public static final int barkInitGVal = 183;
    public static final int barkInitBVal = 107;
    public static final int leafInitRVal = 0;
    public static final int leafInitGVal = 100;
    public static final int leafInitBVal = 0;
    public static final int grassInitRVal = 124;
    public static final int grassInitGVal = 252;
    public static final int grassInitBVal = 0;
    public static final int sunInitRVal = 255;
    public static final int sunInitGVal = 69;
    public static final int sunInitBVal = 0;

    //components
    public CustomCircle treeLeaves;
    public CustomCircle sun;
    public CustomRect grass;
    public CustomRect treeBark;
    public int background;

    private DrawModel drawModel;

    public DrawModel getDrawModel() {
        return this.drawModel;
    }

    public DrawView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setWillNotDraw(false);

        //creating components with the necessary values
        grass = new CustomRect("Grass", argb(alphaVal, grassInitRVal, grassInitGVal, grassInitBVal), grassL, grassT, grassR, grassB);
        treeLeaves = new CustomCircle("Tree Leaves", argb(alphaVal, leafInitRVal, leafInitGVal, leafInitBVal), leavesX, leavesY, leavesR);
        treeBark = new CustomRect("Tree Bark", argb(alphaVal, barkInitRVal, barkInitGVal, barkInitBVal), barkL, barkT, barkR, barkB);
        sun = new CustomCircle("Sun", argb(alphaVal, sunInitRVal, sunInitGVal, sunInitBVal), sunX, sunY, sunR);

        //setting the background ("Sky" component) color
        setBackgroundColor(argb(255, 135, 206, 235));
        background = (argb(255, 135, 206, 235));
        drawModel = new DrawModel();
    }

    //draw the components
    public void onDraw(Canvas canvas) {
        grass.drawMe(canvas);
        treeLeaves.drawMe(canvas);
        treeBark.drawMe(canvas);
        sun.drawMe(canvas);
    }
}
