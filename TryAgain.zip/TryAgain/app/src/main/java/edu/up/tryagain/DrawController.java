package edu.up.tryagain;

import static android.graphics.Color.argb;

import android.graphics.Color;
import android.view.MotionEvent;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;

public class DrawController implements SeekBar.OnSeekBarChangeListener, View.OnTouchListener {

    public DrawView drawView;
    public DrawModel drawModel;
    private SeekBar redSB;
    private SeekBar blueSB;
    private SeekBar greenSB;
    private TextView currElemTV;

    //initializes all necessary views
    public DrawController(DrawView initDV, SeekBar initR, SeekBar initG, SeekBar initB, TextView currElem) {
        this.drawView = initDV;
        this.drawModel = initDV.getDrawModel();
        this.redSB = initR;
        this.greenSB = initG;
        this.blueSB = initB;
        this.currElemTV = currElem;
    }

    /*
        onProgressChanged: checks to see which seekbar was changed, and sets the corresponding RGB
        value to the selectedComponent's color.
     */
    @Override
    public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
        //checking which seekbar was moved
        if (seekBar.getId() == R.id.red_seekBar) {
            drawModel.rVal = seekBar.getProgress();
        } else if (seekBar.getId() == R.id.green_seekBar) {
            drawModel.gVal = seekBar.getProgress();
        } else if (seekBar.getId() == R.id.blue_seekBar) {
            drawModel.bVal = seekBar.getProgress();
        }

        //checking which component is currently selected
        if (drawModel.selectedComponent.equals(drawView.sun.myName)) {
            drawView.sun.setColor(argb(255, drawModel.rVal, drawModel.gVal, drawModel.bVal));
        }
        else if (drawModel.selectedComponent.equals(drawView.treeLeaves.myName)) {
            drawView.treeLeaves.setColor(argb(255, drawModel.rVal, drawModel.gVal, drawModel.bVal));
        }
        else if (drawModel.selectedComponent.equals(drawView.treeBark.myName)) {
            drawView.treeBark.setColor(argb(255, drawModel.rVal, drawModel.gVal, drawModel.bVal));
        }
        else if (drawModel.selectedComponent.equals(drawView.grass.myName)) {
            drawView.grass.setColor(argb(255, drawModel.rVal, drawModel.gVal, drawModel.bVal));
        }
        else if (drawModel.selectedComponent.equals("Sky")) {
            drawView.setBackgroundColor(argb(255, drawModel.rVal, drawModel.gVal, drawModel.bVal));
        }

        //re-draw the view
        drawView.invalidate();
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {
        //don't care about this method
    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {
        //don't care about this method
    }

    //bug: some elements change the color on touch, possibly due to some RGB values being 0?
    /*
        onTouch: checks if the touched area is in an element of the drawView, and sets the
        RGB seekbars with the values of the elements color if so.
     */
    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        int x = (int) motionEvent.getX();
        int y = (int) motionEvent.getY();
        if (drawView.treeLeaves.containsPoint(x, y)) {
            //selectedComponent used in onProgressChanged as well
            drawModel.selectedComponent = drawView.treeLeaves.getName();
            currElemTV.setText(drawModel.selectedComponent);

            //grabbing the individual values
            drawModel.rVal = Color.red(drawView.treeLeaves.getColor());
            drawModel.gVal = Color.green(drawView.treeLeaves.getColor());
            drawModel.bVal = Color.blue(drawView.treeLeaves.getColor());

            //setting their progress on each seekbar
            this.redSB.setProgress(drawModel.rVal);
            this.greenSB.setProgress(drawModel.gVal);
            this.blueSB.setProgress(drawModel.bVal);
        }
        else if (drawView.treeBark.containsPoint(x, y)) {
            drawModel.selectedComponent = drawView.treeBark.getName();
            currElemTV.setText(drawModel.selectedComponent);

            drawModel.rVal = Color.red(drawView.treeBark.getColor());
            drawModel.gVal = Color.green(drawView.treeBark.getColor());
            drawModel.bVal = Color.blue(drawView.treeBark.getColor());

            this.redSB.setProgress(drawModel.rVal);
            this.greenSB.setProgress(drawModel.gVal);
            this.blueSB.setProgress(drawModel.bVal);
        }
        else if (drawView.grass.containsPoint(x, y)) {
            drawModel.selectedComponent = drawView.grass.getName();
            currElemTV.setText(drawModel.selectedComponent);

            drawModel.rVal = Color.red(drawView.grass.getColor());
            drawModel.gVal = Color.green(drawView.grass.getColor());
            drawModel.bVal = Color.blue(drawView.grass.getColor());

            this.redSB.setProgress(drawModel.rVal);
            this.greenSB.setProgress(drawModel.gVal);
            this.blueSB.setProgress(drawModel.bVal);
        }
        else if (drawView.sun.containsPoint(x, y)) {
            drawModel.selectedComponent = drawView.sun.getName();
            currElemTV.setText(drawModel.selectedComponent);

            drawModel.rVal = Color.red(drawView.sun.getColor());
            drawModel.gVal = Color.green(drawView.sun.getColor());
            drawModel.bVal = Color.blue(drawView.sun.getColor());

            this.redSB.setProgress(drawModel.rVal);
            this.greenSB.setProgress(drawModel.gVal);
            this.blueSB.setProgress(drawModel.bVal);
        }
        else {
            drawModel.selectedComponent = "Sky";
            currElemTV.setText(drawModel.selectedComponent);

            drawModel.rVal = Color.red(drawView.background);
            drawModel.gVal = Color.green(drawView.background);
            drawModel.bVal = Color.blue(drawView.background);

            this.redSB.setProgress(drawModel.rVal);
            this.greenSB.setProgress(drawModel.gVal);
            this.blueSB.setProgress(drawModel.bVal);
        }
        return true;
    }
}
