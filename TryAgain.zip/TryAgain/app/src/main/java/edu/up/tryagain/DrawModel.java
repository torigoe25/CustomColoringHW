package edu.up.tryagain;

public class DrawModel {
    public int rVal;
    public int gVal;
    public int bVal;
    public String selectedComponent;
}
